//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; // jan ubah ntr erorr
global.publik = true
global.owner = ["6283115417983"] 
global.namabot = 'LukasCrasher'
//======================
global.mess = { 
owner: '*waduhh!, lu bukan owner gw bg*',
premium: '*anda bukan user premium*',
succes: '*done bang*'
}
//======================